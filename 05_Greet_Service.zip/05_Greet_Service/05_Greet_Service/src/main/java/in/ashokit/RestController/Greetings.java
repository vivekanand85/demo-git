package in.ashokit.RestController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ashokit.cl.WelcomeFeignClient;


@RestController
public class Greetings {
	
	@Autowired
	private WelcomeFeignClient welcomeFeignClient;
	
	@GetMapping("/greet")
	public String greet() {
		String welcomeMsg=welcomeFeignClient.getWelcome();
		
		String greetMsg="Good Morning";

		return welcomeMsg + greetMsg;
		
	}

}
