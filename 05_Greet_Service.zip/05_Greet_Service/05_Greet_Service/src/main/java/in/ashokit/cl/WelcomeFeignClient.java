package in.ashokit.cl;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@FeignClient(name="welcome-service")
public interface WelcomeFeignClient {

	@GetMapping("/welcome")
	public String getWelcome();
}
